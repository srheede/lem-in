# lem-in_test

Tests for your lem-in program. Cool, isn't it?

In order to test your own program:
- download this repo in your `lem-in` folder,
- execute shell script in the same folder as your program:
```
$ sh test/test_lemin.sh
```

Some maps by courtesy of [tbouder](https://github.com/TBouder/lem-in_test).

Enjoy!
